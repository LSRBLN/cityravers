"""
Datenbank-Modell für Accounts, Gruppen und geplante Nachrichten
"""

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, Text, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime

Base = declarative_base()


class Account(Base):
    """Telegram Account (User oder Bot)"""
    __tablename__ = "accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    account_type = Column(String, default="user")  # 'user' oder 'bot'
    api_id = Column(String)  # Nur für User-Accounts
    api_hash = Column(String)  # Nur für User-Accounts
    bot_token = Column(String)  # Nur für Bot-Accounts
    phone_number = Column(String)  # Nur für User-Accounts
    session_name = Column(String, unique=True)  # Nur für User-Accounts
    session_file_path = Column(String)  # Pfad zur hochgeladenen Session-Datei
    tdata_path = Column(String)  # Pfad zum tdata-Ordner
    proxy_id = Column(Integer, ForeignKey("proxies.id"))  # Zugewiesener Proxy
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_used = Column(DateTime)
    
    # Relationships
    scheduled_messages = relationship("ScheduledMessage", back_populates="account", cascade="all, delete-orphan")
    proxy = relationship("Proxy", foreign_keys=[proxy_id])


class Group(Base):
    """Telegram Gruppe/Chat"""
    __tablename__ = "groups"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    chat_id = Column(String, nullable=False, unique=True, index=True)
    chat_type = Column(String)  # 'group', 'channel', 'private'
    username = Column(String)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Neue Felder für Gruppendetails
    member_count = Column(Integer, default=0)  # Anzahl der Mitglieder
    is_public = Column(Boolean, default=True)  # Öffentlich oder privat
    bot_invite_allowed = Column(Boolean, default=True)  # Können Bots eingeladen werden
    description = Column(Text)  # Gruppenbeschreibung
    invite_link = Column(String)  # Einladungslink (falls vorhanden)
    last_checked = Column(DateTime)  # Wann zuletzt geprüft wurde
    
    # Relationships entfernt - verwenden jetzt group_ids (JSON) statt Foreign Key


class ScheduledMessage(Base):
    """Geplante Nachricht"""
    __tablename__ = "scheduled_messages"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    group_ids = Column(Text, nullable=False)  # JSON-Array von Group-IDs für Multi-Gruppen
    message = Column(Text, nullable=False)
    scheduled_time = Column(DateTime, nullable=False, index=True)
    delay = Column(Float, default=1.0)  # Sekunden zwischen Nachrichten
    batch_size = Column(Integer, default=10)
    batch_delay = Column(Float, default=5.0)
    group_delay = Column(Float, default=2.0)  # Sekunden zwischen verschiedenen Gruppen
    repeat_count = Column(Integer, default=1)  # Wie oft soll die Nachricht gesendet werden
    status = Column(String, default="pending")  # pending, running, completed, failed, cancelled
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    sent_count = Column(Integer, default=0)
    failed_count = Column(Integer, default=0)
    error_message = Column(Text)
    
    # Relationships
    account = relationship("Account", back_populates="scheduled_messages")
    # group_ids als JSON gespeichert, keine Foreign Key Relationship mehr


class ScrapedUser(Base):
    """Gescrapte Telegram User"""
    __tablename__ = "scraped_users"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String, nullable=False, index=True)  # Telegram User ID
    username = Column(String, index=True)
    first_name = Column(String)
    last_name = Column(String)
    phone = Column(String)
    source_group_id = Column(String)  # Aus welcher Gruppe gescrapt
    source_group_name = Column(String)
    scraped_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    
    # Metadaten
    notes = Column(Text)  # Notizen zum User


class AccountWarming(Base):
    """Account-Warming Konfiguration"""
    __tablename__ = "account_warming"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False, unique=True)
    is_active = Column(Boolean, default=False)
    
    # Aktivitäts-Limits (pro Tag)
    read_messages_per_day = Column(Integer, default=20)  # Nachrichten lesen
    scroll_dialogs_per_day = Column(Integer, default=10)  # Durch Dialoge scrollen
    reactions_per_day = Column(Integer, default=5)  # Reaktionen
    small_messages_per_day = Column(Integer, default=3)  # Kleine Nachrichten
    
    # Zeitplanung
    start_time = Column(String, default="09:00")  # Startzeit (HH:MM)
    end_time = Column(String, default="22:00")  # Endzeit (HH:MM)
    min_delay = Column(Float, default=30.0)  # Mindest-Delay zwischen Aktionen (Sekunden)
    max_delay = Column(Float, default=300.0)  # Maximal-Delay zwischen Aktionen (Sekunden)
    
    # Warming-Phase (Tage seit Start)
    warming_days = Column(Integer, default=0)  # Wie viele Tage läuft das Warming bereits
    max_warming_days = Column(Integer, default=14)  # Maximale Warming-Dauer
    
    # Statistiken
    total_actions = Column(Integer, default=0)
    last_action_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    account = relationship("Account")


class WarmingActivity(Base):
    """Warming-Aktivitäten Log"""
    __tablename__ = "warming_activities"
    
    id = Column(Integer, primary_key=True, index=True)
    warming_id = Column(Integer, ForeignKey("account_warming.id"), nullable=False)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    activity_type = Column(String, nullable=False)  # 'read', 'scroll', 'reaction', 'message'
    target_chat_id = Column(String)
    target_chat_name = Column(String)
    message_id = Column(Integer)
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    executed_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    warming = relationship("AccountWarming")


class MessageTemplate(Base):
    """Nachrichtenvorlagen für spätere Verwendung"""
    __tablename__ = "message_templates"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)
    message = Column(Text, nullable=False)
    category = Column(String)  # z.B. 'marketing', 'info', 'announcement'
    tags = Column(Text)  # JSON-Array von Tags
    usage_count = Column(Integer, default=0)  # Wie oft verwendet
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, default=True)


class SentMessage(Base):
    """Historie gesendeter Nachrichten"""
    __tablename__ = "sent_messages"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False)
    group_id = Column(Integer, ForeignKey("groups.id"))
    group_chat_id = Column(String)  # Backup falls Gruppe gelöscht
    group_name = Column(String)  # Backup falls Gruppe gelöscht
    message = Column(Text, nullable=False)
    message_template_id = Column(Integer, ForeignKey("message_templates.id"))  # Optional: Verweis auf Vorlage
    sent_at = Column(DateTime, default=datetime.utcnow, index=True)
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    telegram_message_id = Column(String)  # Telegram Message ID falls verfügbar
    
    # Relationships
    account = relationship("Account")
    group = relationship("Group")
    template = relationship("MessageTemplate")


class AccountStatistic(Base):
    """Statistiken für Accounts"""
    __tablename__ = "account_statistics"
    
    id = Column(Integer, primary_key=True, index=True)
    account_id = Column(Integer, ForeignKey("accounts.id"), nullable=False, unique=True, index=True)
    
    # Gesendete Nachrichten
    total_messages_sent = Column(Integer, default=0)
    total_messages_failed = Column(Integer, default=0)
    
    # Gruppen-Statistiken
    total_groups_used = Column(Integer, default=0)
    
    # Zeitstempel
    first_message_at = Column(DateTime)
    last_message_at = Column(DateTime)
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    account = relationship("Account")


class Proxy(Base):
    """Proxy-Konfiguration"""
    __tablename__ = "proxies"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)
    proxy_type = Column(String, nullable=False)  # 'socks5', 'http', 'https', 'mtproto'
    host = Column(String, nullable=False)
    port = Column(Integer, nullable=False)
    username = Column(String)  # Optional
    password = Column(String)  # Optional
    secret = Column(String)  # Für MTProto
    
    # Metadaten
    country = Column(String)  # Optional: Land des Proxys
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)  # Ob Proxy getestet wurde
    last_used = Column(DateTime)
    usage_count = Column(Integer, default=0)  # Wie oft verwendet
    created_at = Column(DateTime, default=datetime.utcnow)
    notes = Column(Text)  # Notizen zum Proxy


# Datenbank initialisieren
def init_db(db_path: str = "telegram_bot.db"):
    """Initialisiert die Datenbank"""
    engine = create_engine(f"sqlite:///{db_path}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    return engine


def get_session(engine):
    """Erstellt eine Datenbank-Session"""
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    return SessionLocal()

