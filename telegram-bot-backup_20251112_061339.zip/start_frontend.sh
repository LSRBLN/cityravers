#!/bin/bash
# Startet das Frontend

echo "🚀 Starte Telegram Mass Message Frontend..."
cd frontend
npm install
npm run dev

